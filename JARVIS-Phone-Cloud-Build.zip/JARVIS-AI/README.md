# JARVIS AI Android Launcher — starter prototype

Tamil-first hybrid assistant starter project for Android (Kotlin).

## Current prototype features
- JARVIS-themed dark home screen
- Can be selected as the Android Home app / launcher
- Tap-to-speak Tamil (`ta-IN`) voice recognition using the Android speech recognizer
- Tamil text-to-speech where the device has a Tamil voice installed
- Launch WhatsApp, YouTube, Camera and Settings
- Save and read simple notes locally on the device
- Typed commands as a fallback

## Build
1. Install Android Studio (Ladybug or newer) and Android SDK Platform 35.
2. Open this folder in Android Studio.
3. Allow Gradle sync; use JDK 17.
4. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Install the generated debug APK on your phone.

## First launch
- Grant microphone permission when prompted.
- Set JARVIS AI as the default Home app if you want to use it as your launcher.
- Speech recognition availability and Tamil TTS voice depend on the Android device and installed Google speech/voice services.

## Important limitations in this starter
- This is a first prototype, not a full autonomous JARVIS.
- Voice activation is tap-to-talk; always-listening wake word is not implemented.
- Hybrid LLM/API connection is not configured; no API key is embedded.
- Screen capture/reading and Accessibility-based automation are not implemented yet. These require explicit Android user consent and careful privacy controls.
- Android may restrict background microphone use and automation in other apps.

## Next development milestones
1. Add secure AI provider settings and hybrid online/offline routing.
2. Add MediaProjection consent flow and on-device OCR for user-approved screen capture.
3. Add an optional Accessibility service for explicitly enabled UI automation.
4. Add a wake-word engine with foreground-service notification and battery controls.
5. Add encrypted local memory, export/delete controls, and command confirmation for sensitive actions.
