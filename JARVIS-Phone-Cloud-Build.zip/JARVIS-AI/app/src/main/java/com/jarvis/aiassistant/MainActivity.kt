package com.jarvis.aiassistant

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.view.inputmethod.InputMethodManager
import android.content.Context
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var tts: TextToSpeech
    private lateinit var status: TextView
    private lateinit var result: TextView
    private lateinit var commandInput: EditText
    private var speechRecognizer: SpeechRecognizer? = null
    private val prefs by lazy { getSharedPreferences("jarvis_memory", MODE_PRIVATE) }
    private val requestAudio = 410
    private val requestSpeech = 411

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        tts = TextToSpeech(this, this)
        status = findViewById(R.id.status)
        result = findViewById(R.id.lastResult)
        commandInput = findViewById(R.id.commandInput)

        findViewById<Button>(R.id.listenButton).setOnClickListener { listen() }
        findViewById<Button>(R.id.runButton).setOnClickListener { runCommand(commandInput.text.toString()) }
        findViewById<Button>(R.id.whatsappButton).setOnClickListener { openApp("com.whatsapp", "WhatsApp") }
        findViewById<Button>(R.id.youtubeButton).setOnClickListener { openApp("com.google.android.youtube", "YouTube") }
        findViewById<Button>(R.id.cameraButton).setOnClickListener { openCamera() }
        findViewById<Button>(R.id.settingsButton).setOnClickListener { startActivity(Intent(android.provider.Settings.ACTION_SETTINGS)) }

        status.text = "தமிழ் குரல் உதவியாளர் தயார்"
        result.text = "சொல்லுங்கள்: ‘ஜார்விஸ், வாட்ஸ்அப் திற’ அல்லது ‘ஜார்விஸ், நினைவில் வை ...’"
    }

    override fun onInit(statusCode: Int) {
        if (statusCode == TextToSpeech.SUCCESS) {
            val tamil = tts.setLanguage(Locale("ta", "IN"))
            if (tamil == TextToSpeech.LANG_MISSING_DATA || tamil == TextToSpeech.LANG_NOT_SUPPORTED) {
                tts.setLanguage(Locale.getDefault())
            }
        }
    }

    private fun listen() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), requestAudio)
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            say("இந்த மொபைலில் குரல் அடையாளம் காணும் வசதி கிடைக்கவில்லை")
            return
        }
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ta-IN")
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "ta-IN")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "ஜார்விஸிடம் பேசுங்கள்")
        }
        try {
            startActivityForResult(intent, requestSpeech)
            status.text = "கேட்டுக்கொண்டிருக்கிறேன்..."
        } catch (_: Exception) {
            say("குரல் சேவையை திறக்க முடியவில்லை")
        }
    }

    @Deprecated("Deprecated by Android, retained for broad device compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == requestSpeech && resultCode == RESULT_OK) {
            val spoken = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull().orEmpty()
            commandInput.setText(spoken)
            runCommand(spoken)
        }
    }

    private fun runCommand(raw: String) {
        val command = raw.trim().lowercase(Locale.ROOT)
        if (command.isBlank()) return
        result.text = "நீங்கள் சொன்னது: $raw"
        when {
            command.contains("நினைவில் வை") || command.contains("save this") || command.contains("remember") || command.contains("சேமி") -> {
                val note = raw.replace(Regex("(?i)ஜார்விஸ்[ ,]*"), "")
                    .replace("நினைவில் வை", "").replace("சேமி", "").trim()
                val old = prefs.getString("notes", "").orEmpty()
                prefs.edit().putString("notes", (old + "\n" + note).trim()).apply()
                say("சரி. இதை நினைவில் சேமித்துவிட்டேன்")
                result.append("\nசேமித்த நினைவுகள்: " + prefs.getString("notes", ""))
            }
            command.contains("நினைவுகள்") || command.contains("என்ன சேமிச்ச") || command.contains("show notes") -> {
                val notes = prefs.getString("notes", "").orEmpty()
                say(if (notes.isBlank()) "இன்னும் எதுவும் சேமிக்கவில்லை" else "உங்கள் சேமித்த குறிப்புகளை காட்டுகிறேன்")
                result.text = if (notes.isBlank()) "சேமித்த குறிப்புகள் இல்லை" else notes
            }
            command.contains("whatsapp") || command.contains("வாட்ஸ்அப்") -> openApp("com.whatsapp", "WhatsApp")
            command.contains("youtube") || command.contains("யூடியூப்") -> openApp("com.google.android.youtube", "YouTube")
            command.contains("camera") || command.contains("கேமரா") -> openCamera()
            command.contains("settings") || command.contains("செட்டிங்") || command.contains("அமைப்புகள்") -> {
                startActivity(Intent(android.provider.Settings.ACTION_SETTINGS)); say("அமைப்புகளை திறக்கிறேன்")
            }
            command.contains("maps") || command.contains("மேப்") || command.contains("வழி") -> {
                val map = Intent(Intent.ACTION_VIEW, android.net.Uri.parse("geo:0,0?q="))
                if (map.resolveActivity(packageManager) != null) startActivity(map) else say("Maps செயலி கிடைக்கவில்லை")
            }
            command.contains("call") || command.contains("அழை") || command.contains("கால்") -> {
                say("யாரை அழைக்க வேண்டும் என்பதை தொடர்புகள் செயலியில் தேர்வு செய்யுங்கள்")
                startActivity(Intent(Intent.ACTION_DIAL))
            }
            else -> say("இந்த கட்டளையை இன்னும் கற்றுக்கொள்ளவில்லை. இப்போது WhatsApp, YouTube, Camera, Settings மற்றும் குறிப்புகளை கையாள முடியும்")
        }
    }

    private fun openApp(packageName: String, label: String) {
        val launch = packageManager.getLaunchIntentForPackage(packageName)
        if (launch != null) { startActivity(launch); say("$label திறக்கிறேன்") }
        else say("$label செயலி இந்த மொபைலில் இல்லை")
    }

    private fun openCamera() {
        val intent = Intent("android.media.action.IMAGE_CAPTURE")
        if (intent.resolveActivity(packageManager) != null) { startActivity(intent); say("கேமராவை திறக்கிறேன்") }
        else say("கேமரா செயலி கிடைக்கவில்லை")
    }

    private fun say(message: String) {
        status.text = message
        if (::tts.isInitialized) tts.speak(message, TextToSpeech.QUEUE_FLUSH, null, "jarvis_reply")
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == requestAudio && grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) listen()
        else if (requestCode == requestAudio) say("குரல் கட்டளைக்கு மைக்ரோஃபோன் அனுமதி தேவை")
    }

    override fun onDestroy() {
        speechRecognizer?.destroy()
        if (::tts.isInitialized) { tts.stop(); tts.shutdown() }
        super.onDestroy()
    }
}
